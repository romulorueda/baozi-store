package com.romulo.baozi_store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaoziStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaoziStoreApplication.class, args);
	}

}
